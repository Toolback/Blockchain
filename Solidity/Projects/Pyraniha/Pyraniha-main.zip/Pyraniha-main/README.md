## Pyraniha <3

Game Idea : 
https://excalidraw.com/#json=zsx6gqjAX0wmg3kzMfhJA,oWuWtqcRjeasVrj6gKmFoA

[TO DO LIST]

- [X] Fix Contracts inheritance
- [] Set up NFT config 
- [-] Fix Level Up function in PyranihaHelper
- [] Configure an exp limit as long as the player has not chose to level up once the max exp is reached
- [] Implement choices in Daily Adventure
- [] Implement Karma point (store "influence" - > type choices of D-A)
- []
- []
- []
- []
- []
- [] Tests what remix cant 