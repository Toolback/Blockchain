const CharactereERC721 = artifacts.require("CharactereERC721");

module.exports = async function(deployer) {
  const accounts = await web3.eth.getAccounts()

  await deployer.deploy(CharactereERC721);
};
