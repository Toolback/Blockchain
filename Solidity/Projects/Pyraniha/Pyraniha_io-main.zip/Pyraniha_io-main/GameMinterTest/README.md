# ✅ [Pyraniha] Minting Page

# 🪜 [LAUNCH]

  Lets connect to Metamask Rinkeby TestNetWork on your webrowser

  then on your terminal's directory run : 

- npm install
- npm run start



# 🪜 [TODO]

[] Fix dotenv for pinata key 
[] Add DB Metadata Attributs/Caract storage + creation with pinata CID
[] fetch SM methods 
[] import pyraniha user's image on front when minted
[] import ERC 1155 + Logic handler 

# [Dotenv Template]

INFURA_API="INFURA-PUBLIC-KEY"
PRIVATE_KEY="PRIVATE-ADMIN-KEY"
PUBLIC_KEY="PUBLIC-ADMIN-KEY"
REACT_APP_PINATA_KEY="PINATA-KEY"
REACT_APP_PINATA_SECRET="PINATA-PRIVATE-KEY"