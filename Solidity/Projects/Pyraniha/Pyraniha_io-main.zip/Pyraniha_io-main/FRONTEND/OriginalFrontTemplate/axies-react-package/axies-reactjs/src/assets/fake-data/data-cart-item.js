import img1 from '../images/box-item/img_cart_item.jpg';


const cartItemData = [
    {
        img : "",
        title: "",
        position: ""
    },

]

export default cartItemData;