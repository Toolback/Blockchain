const menus = [
    {
        id: 1,
        name: 'World',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Home',
                links: '/game'
            },
            {
                id: 2,
                sub: 'Adventure',
                links: '#'
            },
            {
                id: 3,
                sub: 'School',
                links: '/ranking'
            },
            {
                id: 4,
                sub: 'Black Market',
                links: '/ranking'
            }
            
        ],
    },
    {
        id: 2,
        name: 'Market Place',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Buy Token (Coming Soon)',
                links: '#'
            },
            {
                id: 2,
                sub: 'NFTs',
                links: '/explore-04'
            },
            {
                id: 3,
                sub: 'Statistics',
                links: '/ranking'
            }
            
        ],
    },
    {
        id: 3,
        name: 'Staking',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Coming Soon',
                links: '#'
            },
        ],
    },,
    {
        id: 4,
        name: 'Community',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Mairie',
                links: '/blog'
            },
            {
                id: 2,
                sub: 'City tchat',
                links: '#'
            },
            {
                id: 3,
                sub: 'Government',
                links: '#'
            }, 
            {
                id: 4,
                sub: 'Prison',
                links: '#'
            }
        ],
    },
    {
        id: 5,
        name: 'More',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Quit the Game',
                links: '/'
            },
            {
                id: 2,
                sub: 'FAQ',
                links: '/faq'
            },
            {
                id: 3,
                sub: 'Help Center',
                links: '/help-center'
            },
            {
                id: 4,
                sub: 'Contributors',
                links: '/authors-01'
            }
        ],
    },
    
]

export default menus;