import { render } from "@testing-library/react"
var story;

function getStory(name) {
  return {
    currentScene: "attack",
    attack: {
      title: "Chapter 1",
      story: `Try story 1 to replace later with adventure 1 basil history with ${name}`,
      choices: [
        {
          choice: "Yes",
          destination: "",
        },
        {
          choice: "Nop",
          destination: "",
        }
      ]
    },
    battle: {
      title: 'The epic battle for cute Puppistan!',
      story: `It's avarice the angru sdlfkjsmlj`,
      choices: [
        {
          choice: "Attack him with sword",
          destination: 'sword'
        },
        {
          choice: "Attack him with carrot",
          destination: 'carrot'
        }
      ]
    },
    goHome: {
      title: "Back at Home !",
      story: "Yes, you're back in comfort of your own home. Don't worry about it, somone else took care of the problems.",
      image: "basil",
      defaultDestination: 'attack',
      buttonText: "Let's try this again"
    }
  }
}

document.addEventListener('DOMContentLoaded', function () {
  var button = document.querySelector('#start-button')
  var content = document.querySelector('#content')
  button.addEventListener('click', function() {
    var name = document.querySelector('#name-input')
    story = getStory(name.value)
    renderScene()


  })
})

function renderScene() {
  var text = "Next";
  var image = "";
  if (story[story.currentScene].image) {
    image = "<img></img>"
  }
  if (story[story.currentScene].buttonText) {
    text = story[story.currentScene].buttonText
  }
  content.innerHTML = `
  <h1>${story[story.currentScene].title}</h1>
  <p>${story[story.currentScene].story}</p>
  ${image}
  ${getInputs()}
  <button id = "submit-button">${text}</button>
  `
  if (story[story.currentScene].image) {
    document.querySelector("image").src = `./img/${story[story.currentScene].image}`
  }

  var button = document.querySelector("#submit-button");
  button.addEventListener('click', function () {
    getInputValue()
  })
}

function getInputValue() {
  var inputs = document.querySelectorAll('input[type="radio"]');
  for (var i = 0; i < inputs.length; i++) {
    if (inputs[i].checked) {
      story.currentScene = inputs[i].getAttribute('data-destination')
      renderScene();
      return;

    }
  }
  story.currentScene = story[story.currentScene].defaultDestination
  renderScene()
}

function getInputs() {
  var input = ""
  if (!story[story.currentScene].choices) {
    return ""
  }
  for (var i = 0; i < story[story.currentScene].choices.length; i++) {
    input += `
    <div>
    <input data-destination = ${story[story.currentScene].choices[i].destination} id = "radios${i}" type = "radio" name = "choices" />
    <label for "radio${i}">${story[story.currentScene].choices[i].choice}</label>
    </div>`
  }
  return input;
}