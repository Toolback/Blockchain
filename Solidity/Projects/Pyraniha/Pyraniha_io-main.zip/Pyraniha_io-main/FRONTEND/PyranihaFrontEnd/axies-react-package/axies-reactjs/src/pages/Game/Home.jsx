import React from 'react';
import GHeader from '../../components/CGame/GHeader';
import heroSliderData from '../../components/CGame/data-slider';
import GHomeNav from '../../components/CGame/GHomeNav';

const GHome = () => {

    return (
        <div className='home-1'>
            <GHeader />
            <GHomeNav data={heroSliderData} />
        </div>
    );
}

export default GHome;
