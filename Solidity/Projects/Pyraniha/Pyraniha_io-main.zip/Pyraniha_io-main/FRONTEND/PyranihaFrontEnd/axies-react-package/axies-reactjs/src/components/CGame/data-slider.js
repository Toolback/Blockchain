import img1 from '../../assets/images/slider/Pyraniha01.png';
import imgbg1 from '../../assets/images/slider/bg_slide_1.png'


const heroSliderData = [
    {
        title_1: "Thiel",
        title_2: "Solitaire",
        title_3: "level 1",
        description: "Young Pyraniha in greed for adventure and glory <3 ",
        img: img1,
        imgbg: imgbg1,
        class:'left'
    }
    
]

export default heroSliderData;