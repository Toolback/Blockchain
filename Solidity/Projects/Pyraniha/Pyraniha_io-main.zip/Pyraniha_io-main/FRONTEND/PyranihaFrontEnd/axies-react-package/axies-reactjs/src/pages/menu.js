const menus = [
    {
        id: 1,
        name: 'Home',
        links: '/',
    },
    {
        id: 2,
        name: 'Market Place',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Buy Token (Coming Soon)',
                links: '#'
            },
            {
                id: 2,
                sub: 'NFTs',
                links: '/explore-04'
            },
            {
                id: 6,
                sub: 'Statistics',
                links: '/ranking'
            }
            
        ],
    },
    {
        id: 3,
        name: 'Staking',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Coming Soon',
                links: '#'
            },
        ],
    },,
    {
        id: 4,
        name: 'Community',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Blog',
                links: '/blog'
            },
            {
                id: 2,
                sub: 'Discord',
                links: '#'
            },
            {
                id: 3,
                sub: 'Telegram',
                links: '#'
            }, 
            {
                id: 4,
                sub: 'Twitter',
                links: '#'
            }
        ],
    },
    {
        id: 5,
        name: 'More',
        links: '#',
        namesub: [
            {
                id: 1,
                sub: 'Contact',
                links: '/contact-01'
            },
            {
                id: 2,
                sub: 'FAQ',
                links: '/faq'
            },
            {
                id: 3,
                sub: 'Help Center',
                links: '/help-center'
            },
            {
                id: 4,
                sub: 'Contributors',
                links: '/authors-01'
            }
        ],
    },
    
]

export default menus;