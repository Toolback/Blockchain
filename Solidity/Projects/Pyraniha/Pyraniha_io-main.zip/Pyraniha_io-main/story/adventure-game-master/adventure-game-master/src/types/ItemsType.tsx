type items = "Gun" | "Flashlight";

export default items;
