#!/usr/bin/env bash
rm -rf flats/*
./node_modules/.bin/truffle-flattener contracts/PyranihaDailyAdventure.sol > flats/PyranihaDailyAdventure_flat.sol
