const Pyranihagame = artifacts.require("Pyranihagame");

module.exports = async function(deployer) {
  const accounts = await web3.eth.getAccounts()

  await deployer.deploy(Pyranihagame);
};
