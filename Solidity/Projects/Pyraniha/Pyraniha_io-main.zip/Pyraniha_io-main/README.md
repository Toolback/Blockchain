## Pyraniha <3

Game Idea : 
https://excalidraw.com/#json=ApcJ0gLe1dlm5L_SnHmug,z_7sfYYIu_Rn_B2NPuqhGA

[TO DO LIST]

- [-] Smart contracts (nft/token)
- [-] FrontEnd / Game Interface  
- [] Landing Page (Marketing + socials posts)
- [-] Design / NFTs
- [] Define RoadMap
- [] 
- [] 
- []
- []
- []
- []
- []
- [] 